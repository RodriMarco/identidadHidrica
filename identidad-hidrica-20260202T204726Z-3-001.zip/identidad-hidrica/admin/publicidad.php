<?php
require_once __DIR__ . '/../functions.php';
verificarAdmin();

$mensaje = '';
$pubs = getPublicidad();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['action'] === 'add') {
        $nueva = [
            'titulo' => $_POST['titulo'],
            'descripcion' => $_POST['descripcion'] ?? '',
            'url' => $_POST['url'] ?? '#',
            'imagen' => '',
            'posicion' => $_POST['posicion'],
            'activo' => true
        ];
        if (!empty($_FILES['imagen']['name'])) {
            $result = subirImagen($_FILES['imagen']);
            if (isset($result['url'])) $nueva['imagen'] = $result['url'];
        }
        $pubs[] = $nueva;
        guardarPublicidad($pubs);
        $mensaje = '✅ Publicidad agregada';
    } elseif ($_POST['action'] === 'delete') {
        array_splice($pubs, (int)$_POST['index'], 1);
        guardarPublicidad($pubs);
        $mensaje = '🗑️ Publicidad eliminada';
    } elseif ($_POST['action'] === 'toggle') {
        $pubs[(int)$_POST['index']]['activo'] = !$pubs[(int)$_POST['index']]['activo'];
        guardarPublicidad($pubs);
        $mensaje = '✅ Estado actualizado';
    }
    $pubs = getPublicidad();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publicidad | Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>body{background:#f5f8fa;}</style>
</head>
<body>
    <header class="admin-header">
        <div style="display:flex;align-items:center;gap:15px;"><span style="font-size:1.5rem;">💧</span><div><h1 style="font-size:1.2rem;margin:0;">Panel de Administración</h1></div></div>
        <nav class="admin-nav">
            <a href="index.php">📊 Dashboard</a>
            <a href="articulos.php">📝 Artículos</a>
            <a href="videos.php">🎥 Videos</a>
            <a href="publicidad.php" class="active">📢 Publicidad</a>
            <a href="../index.php" target="_blank">🌐 Ver sitio</a>
            <a href="logout.php">🚪 Salir</a>
        </nav>
    </header>

    <div class="admin-content">
        <?php if ($mensaje): ?><div class="message success"><?= $mensaje ?></div><?php endif; ?>

        <h2 style="font-family:var(--font-display);font-size:2rem;margin-bottom:30px;">📢 Publicidad</h2>

        <div class="admin-card" style="margin-bottom:30px;">
            <h2>➕ Agregar Banner</h2>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
                    <div class="form-group"><label>Título/Anunciante *</label><input type="text" name="titulo" required placeholder="Nombre del anunciante"></div>
                    <div class="form-group"><label>Posición *</label>
                        <select name="posicion" required>
                            <option value="header">Header (Banner superior)</option>
                            <option value="sidebar">Sidebar (Lateral)</option>
                            <option value="footer">Footer (Inferior)</option>
                        </select>
                    </div>
                </div>
                <div class="form-group"><label>Descripción</label><input type="text" name="descripcion" placeholder="Texto breve (opcional)"></div>
                <div class="form-group"><label>URL de destino</label><input type="url" name="url" placeholder="https://..."></div>
                <div class="form-group"><label>Imagen del banner</label><input type="file" name="imagen" accept="image/*"></div>
                <button type="submit" class="btn-primary">➕ Agregar Banner</button>
            </form>
        </div>

        <div class="admin-card">
            <h2>📋 Banners Activos (<?= count($pubs) ?>)</h2>
            <?php if (empty($pubs)): ?>
            <p style="color:#999;padding:20px 0;">No hay publicidades configuradas.</p>
            <?php else: ?>
            <table class="admin-table">
                <thead><tr><th>Anunciante</th><th>Posición</th><th>Estado</th><th>Acciones</th></tr></thead>
                <tbody>
                <?php foreach ($pubs as $i => $pub): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($pub['titulo']) ?></strong></td>
                    <td><?= ucfirst($pub['posicion']) ?></td>
                    <td><span class="status-badge <?= $pub['activo'] ? 'status-published' : 'status-draft' ?>"><?= $pub['activo'] ? 'Activo' : 'Pausado' ?></span></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="index" value="<?= $i ?>">
                            <button type="submit" style="background:#e3f2fd;color:#1976d2;padding:6px 12px;border:none;border-radius:6px;cursor:pointer;"><?= $pub['activo'] ? 'Pausar' : 'Activar' ?></button>
                        </form>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('¿Eliminar?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="index" value="<?= $i ?>">
                            <button type="submit" style="background:#ffebee;color:#c62828;padding:6px 12px;border:none;border-radius:6px;cursor:pointer;">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
