<?php
/**
 * IDENTIDAD HÍDRICA - Página Principal
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

// Obtener contenido
$destacados = getArticulos(3, null, true);
if (empty($destacados)) {
    $destacados = getArticulos(3);
}
$geopolitica = getArticulos(4, 'geopolitica');
$sustentabilidad = getArticulos(4, 'sustentabilidad');
$agro = getArticulos(3, 'agro');
$columnas = getArticulos(3, 'columnas');
$lifestyle = getArticulos(4, 'lifestyle');
$videos = getVideos(5);

// Publicidad - obtener todas las activas
$pubHeader = getPublicidad('header');
$pubSidebar = getPublicidad('sidebar');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?> | <?= SITE_SLOGAN ?></title>
    <meta name="description" content="<?= SITE_SLOGAN ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="container top-bar-content">
            <span>📍 Argentina</span>
            <div class="social-links">
                <a href="#">Instagram</a>
                <a href="#">Twitter</a>
                <a href="#">YouTube</a>
            </div>
        </div>
    </div>

    <!-- Header -->
    <header class="header">
        <div class="header-main container">
            <a href="index.php" class="logo">
                <div class="logo-icon">💧</div>
                <div>
                    <div class="logo-text">IDENTIDAD HÍDRICA</div>
                    <div class="logo-tagline"><?= SITE_SLOGAN ?></div>
                </div>
            </a>
            <button class="mobile-menu-btn" onclick="document.getElementById('navList').classList.toggle('active')">☰</button>
        </div>
        <nav class="nav">
            <div class="container">
                <ul class="nav-list" id="navList">
                    <li><a href="index.php" class="active">Portada</a></li>
                    <li><a href="categoria.php?c=geopolitica">Geopolítica</a></li>
                    <li><a href="categoria.php?c=sustentabilidad">Sustentabilidad</a></li>
                    <li class="dropdown">
                        <a href="categoria.php?c=lifestyle">Lifestyle ▾</a>
                        <div class="dropdown-menu">
                            <a href="categoria.php?c=gourmet">Agua Gourmet</a>
                            <a href="categoria.php?c=deportes">Deportes Acuáticos</a>
                            <a href="categoria.php?c=decoracion">Decoración</a>
                            <a href="categoria.php?c=tecnologia">Tecnología</a>
                        </div>
                    </li>
                    <li><a href="categoria.php?c=agro" class="nav-agro">🌾 Agro</a></li>
                    <li><a href="categoria.php?c=columnas" class="nav-columnas">✒️ Columnas</a></li>
                    <li><a href="videos.php">Videos</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <!-- Hero Section -->
        <?php if (!empty($destacados)): ?>
        <section class="hero">
            <div class="container">
                <div class="hero-grid">
                    <?php $d = $destacados[0]; $cat = getCategoria($d['categoria']); ?>
                    <article class="hero-main" onclick="location.href='articulo.php?s=<?= $d['slug'] ?>'">
                        <?php if ($d['imagen']): ?>
                            <img src="<?= $d['imagen'] ?>" alt="">
                        <?php else: ?>
                            <div style="background:linear-gradient(135deg,#162447,#0a1628);width:100%;height:100%;"></div>
                        <?php endif; ?>
                        <div class="hero-overlay">
                            <span class="tag" style="background:<?= $cat['color'] ?>"><?= $cat['nombre'] ?></span>
                            <h1><?= htmlspecialchars($d['titulo']) ?></h1>
                            <p><?= htmlspecialchars($d['extracto']) ?></p>
                        </div>
                    </article>
                    <div class="hero-sidebar">
                        <?php for ($i = 1; $i <= 2; $i++): if (isset($destacados[$i])): $d = $destacados[$i]; $cat = getCategoria($d['categoria']); ?>
                        <article class="hero-card" onclick="location.href='articulo.php?s=<?= $d['slug'] ?>'">
                            <?php if ($d['imagen']): ?>
                                <img src="<?= $d['imagen'] ?>" alt="">
                            <?php else: ?>
                                <div style="background:linear-gradient(135deg,#1f6f8b,#0a1628);width:100%;height:100%;position:absolute;top:0;left:0;"></div>
                            <?php endif; ?>
                            <div class="hero-overlay">
                                <span class="tag" style="background:<?= $cat['color'] ?>"><?= $cat['nombre'] ?></span>
                                <h2><?= htmlspecialchars($d['titulo']) ?></h2>
                            </div>
                        </article>
                        <?php endif; endfor; ?>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- BANNER PUBLICITARIO HEADER -->
        <?php if (!empty($pubHeader)): $banner = $pubHeader[0]; ?>
        <div class="container">
            <div class="ad-banner">
                <span class="ad-label">Publicidad</span>
                <?php if (!empty($banner['imagen'])): ?>
                    <a href="<?= $banner['url'] ?: '#' ?>" target="_blank">
                        <img src="<?= $banner['imagen'] ?>" alt="<?= htmlspecialchars($banner['titulo']) ?>" style="max-width:100%;border-radius:8px;">
                    </a>
                <?php else: ?>
                    <div class="ad-content">
                        <h3><?= htmlspecialchars($banner['titulo']) ?></h3>
                        <?php if (!empty($banner['descripcion'])): ?>
                            <p><?= htmlspecialchars($banner['descripcion']) ?></p>
                        <?php endif; ?>
                        <?php if (!empty($banner['url'])): ?>
                            <a href="<?= $banner['url'] ?>" class="btn" target="_blank">Más información →</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Geopolítica -->
        <?php if (!empty($geopolitica)): ?>
        <section class="section">
            <div class="container">
                <div class="section-header">
                    <h2>🌍 Geopolítica del Agua</h2>
                    <a href="categoria.php?c=geopolitica">Ver todas →</a>
                </div>
                <div class="news-grid">
                    <?php foreach ($geopolitica as $art): $cat = getCategoria($art['categoria']); ?>
                    <article class="news-card" onclick="location.href='articulo.php?s=<?= $art['slug'] ?>'">
                        <div class="news-card-image">
                            <?php if ($art['imagen']): ?>
                                <img src="<?= $art['imagen'] ?>" alt="">
                            <?php else: ?>
                                <div style="background:linear-gradient(135deg,<?= $cat['color'] ?>,#0a1628);width:100%;height:100%;"></div>
                            <?php endif; ?>
                            <span class="tag" style="background:<?= $cat['color'] ?>"><?= $cat['nombre'] ?></span>
                        </div>
                        <div class="news-card-content">
                            <h3><?= htmlspecialchars($art['titulo']) ?></h3>
                            <p><?= htmlspecialchars($art['extracto']) ?></p>
                            <span class="meta"><?= tiempoRelativo($art['fecha']) ?></span>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- AGRO Section -->
        <?php if (!empty($agro)): ?>
        <section class="agro-section">
            <div class="container">
                <div class="section-header" style="border-color:rgba(255,255,255,0.2);">
                    <h2 style="color:white;">🌾 Agro & Riego</h2>
                    <a href="categoria.php?c=agro" style="color:#90ee90;">Ver todas →</a>
                </div>
                <div class="agro-grid">
                    <?php foreach ($agro as $art): ?>
                    <article class="agro-card" onclick="location.href='articulo.php?s=<?= $art['slug'] ?>'">
                        <span class="tag" style="background:#40916c;">Agro</span>
                        <h3><?= htmlspecialchars($art['titulo']) ?></h3>
                        <p><?= htmlspecialchars($art['extracto']) ?></p>
                        <span class="meta">Por <?= htmlspecialchars($art['autor']) ?></span>
                    </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Sustentabilidad -->
        <?php if (!empty($sustentabilidad)): ?>
        <section class="section">
            <div class="container">
                <div class="section-header">
                    <h2>🌱 Sustentabilidad</h2>
                    <a href="categoria.php?c=sustentabilidad">Ver todas →</a>
                </div>
                <div class="news-grid">
                    <?php foreach ($sustentabilidad as $art): $cat = getCategoria($art['categoria']); ?>
                    <article class="news-card" onclick="location.href='articulo.php?s=<?= $art['slug'] ?>'">
                        <div class="news-card-image">
                            <?php if ($art['imagen']): ?>
                                <img src="<?= $art['imagen'] ?>" alt="">
                            <?php else: ?>
                                <div style="background:linear-gradient(135deg,<?= $cat['color'] ?>,#0a1628);width:100%;height:100%;"></div>
                            <?php endif; ?>
                            <span class="tag" style="background:<?= $cat['color'] ?>"><?= $cat['nombre'] ?></span>
                        </div>
                        <div class="news-card-content">
                            <h3><?= htmlspecialchars($art['titulo']) ?></h3>
                            <p><?= htmlspecialchars($art['extracto']) ?></p>
                            <span class="meta"><?= tiempoRelativo($art['fecha']) ?></span>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- COLUMNAS Section -->
        <?php if (!empty($columnas)): ?>
        <section class="columnas-section">
            <div class="container">
                <div class="section-header" style="border-color:rgba(201,169,98,0.3);">
                    <h2 style="color:#c9a962;">✒️ Columnas de Opinión</h2>
                    <a href="categoria.php?c=columnas" style="color:#c9a962;">Ver todas →</a>
                </div>
                <div class="columnas-grid">
                    <?php foreach ($columnas as $art): ?>
                    <article class="columna-card" onclick="location.href='articulo.php?s=<?= $art['slug'] ?>'">
                        <div class="columna-avatar">👤</div>
                        <h4><?= htmlspecialchars($art['autor']) ?></h4>
                        <span>Columnista</span>
                        <h3>"<?= htmlspecialchars($art['titulo']) ?>"</h3>
                    </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Lifestyle -->
        <?php if (!empty($lifestyle)): ?>
        <section class="section">
            <div class="container">
                <div class="section-header">
                    <h2>💧 Lifestyle</h2>
                    <a href="categoria.php?c=lifestyle">Ver todas →</a>
                </div>
                <div class="lifestyle-tabs">
                    <a href="categoria.php?c=gourmet" class="tab">Agua Gourmet</a>
                    <a href="categoria.php?c=deportes" class="tab">Deportes Acuáticos</a>
                    <a href="categoria.php?c=decoracion" class="tab">Decoración</a>
                    <a href="categoria.php?c=tecnologia" class="tab">Tecnología</a>
                </div>
                <div class="news-grid">
                    <?php foreach ($lifestyle as $art): $cat = getCategoria($art['categoria']); ?>
                    <article class="news-card" onclick="location.href='articulo.php?s=<?= $art['slug'] ?>'">
                        <div class="news-card-image">
                            <?php if ($art['imagen']): ?>
                                <img src="<?= $art['imagen'] ?>" alt="">
                            <?php else: ?>
                                <div style="background:linear-gradient(135deg,<?= $cat['color'] ?>,#0a1628);width:100%;height:100%;"></div>
                            <?php endif; ?>
                            <span class="tag" style="background:<?= $cat['color'] ?>"><?= $cat['nombre'] ?></span>
                        </div>
                        <div class="news-card-content">
                            <h3><?= htmlspecialchars($art['titulo']) ?></h3>
                            <p><?= htmlspecialchars($art['extracto']) ?></p>
                            <span class="meta"><?= tiempoRelativo($art['fecha']) ?></span>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Videos -->
        <?php if (!empty($videos)): ?>
        <section class="section videos-section">
            <div class="container">
                <div class="section-header">
                    <h2>📹 Videoteca</h2>
                    <a href="videos.php">Ver todos →</a>
                </div>
                <div class="videos-grid">
                    <div class="video-featured">
                        <?php $vid = $videos[0]; $vidId = getYoutubeId($vid['url']); ?>
                        <iframe src="https://www.youtube.com/embed/<?= $vidId ?>" title="<?= htmlspecialchars($vid['titulo']) ?>" frameborder="0" allowfullscreen></iframe>
                    </div>
                    <div class="video-sidebar">
                        <?php for ($i = 1; $i < min(4, count($videos)); $i++): $vid = $videos[$i]; $vidId = getYoutubeId($vid['url']); ?>
                        <div class="video-item" onclick="window.open('<?= $vid['url'] ?>', '_blank')">
                            <div class="video-thumb">
                                <img src="https://img.youtube.com/vi/<?= $vidId ?>/mqdefault.jpg" alt="">
                                <span>▶</span>
                            </div>
                            <div class="video-info">
                                <h5><?= htmlspecialchars($vid['titulo']) ?></h5>
                                <small><?= $vid['duracion'] ?? '' ?></small>
                            </div>
                        </div>
                        <?php endfor; ?>
                        
                        <!-- Sidebar Ad -->
                        <?php if (!empty($pubSidebar)): $sideAd = $pubSidebar[0]; ?>
                        <div class="sidebar-ad">
                            <span class="ad-label">Publicidad</span>
                            <?php if (!empty($sideAd['imagen'])): ?>
                                <a href="<?= $sideAd['url'] ?: '#' ?>" target="_blank">
                                    <img src="<?= $sideAd['imagen'] ?>" alt="" style="max-width:100%;border-radius:8px;">
                                </a>
                            <?php else: ?>
                                <h4><?= htmlspecialchars($sideAd['titulo']) ?></h4>
                                <p><?= htmlspecialchars($sideAd['descripcion']) ?></p>
                                <a href="<?= $sideAd['url'] ?: '#' ?>" target="_blank">Más info</a>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                        <div class="sidebar-ad">
                            <span class="ad-label">Espacio Disponible</span>
                            <h4>Publicite aquí</h4>
                            <p>Llegue a decisores del sector hídrico</p>
                            <a href="mailto:contacto@identidadhidrica.com.ar">Contactar</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Newsletter -->
        <div class="container">
            <div class="newsletter">
                <div class="newsletter-text">
                    <h3>📬 Suscribite al Newsletter</h3>
                    <p>Las noticias más importantes del agua, directo a tu casilla</p>
                </div>
                <form class="newsletter-form" method="POST">
                    <input type="email" name="email" placeholder="Tu email" required>
                    <button type="submit">Suscribirme</button>
                </form>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <div class="logo-text">IDENTIDAD HÍDRICA</div>
                    <p><?= SITE_SLOGAN ?></p>
                </div>
                <div class="footer-column">
                    <h4>Secciones</h4>
                    <ul>
                        <li><a href="categoria.php?c=geopolitica">Geopolítica</a></li>
                        <li><a href="categoria.php?c=sustentabilidad">Sustentabilidad</a></li>
                        <li><a href="categoria.php?c=agro">Agro</a></li>
                        <li><a href="categoria.php?c=columnas">Columnas</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Lifestyle</h4>
                    <ul>
                        <li><a href="categoria.php?c=gourmet">Agua Gourmet</a></li>
                        <li><a href="categoria.php?c=deportes">Deportes</a></li>
                        <li><a href="categoria.php?c=decoracion">Decoración</a></li>
                        <li><a href="categoria.php?c=tecnologia">Tecnología</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Multimedia</h4>
                    <ul>
                        <li><a href="videos.php">Videos</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <span>© <?= date('Y') ?> <?= SITE_NAME ?>. Todos los derechos reservados.</span>
            </div>
        </div>
    </footer>
</body>
</html>
