<?php
/**
 * IDENTIDAD HÍDRICA - Configuración del Sitio
 * 
 * ⚠️ IMPORTANTE: Cambiá la contraseña antes de subir al servidor
 */

// Información del sitio
define('SITE_NAME', 'Identidad Hídrica');
define('SITE_SLOGAN', 'Único medio especializado en los usos del agua');
define('SITE_URL', 'http://localhost/identidad-hidrica');

// ⚠️ CREDENCIALES DEL ADMIN - ¡CAMBIAR ANTES DE SUBIR!
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'IH2026agua!'); // Cambiá esta contraseña

// Rutas del sistema (no modificar)
define('ROOT_PATH', __DIR__);
define('DATA_PATH', ROOT_PATH . '/data');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('UPLOADS_URL', '/uploads');

// Configuración
define('ARTICLES_PER_PAGE', 12);

// Categorías del sitio
$CATEGORIAS = [
    'geopolitica' => ['nombre' => 'Geopolítica', 'color' => '#2d9cdb', 'icono' => '🌍'],
    'sustentabilidad' => ['nombre' => 'Sustentabilidad', 'color' => '#1f6f8b', 'icono' => '🌱'],
    'agro' => ['nombre' => 'Agro', 'color' => '#2d6a4f', 'icono' => '🌾'],
    'columnas' => ['nombre' => 'Columnas', 'color' => '#c9a962', 'icono' => '✒️'],
    'lifestyle' => ['nombre' => 'Lifestyle', 'color' => '#56d5e8', 'icono' => '💧'],
    'gourmet' => ['nombre' => 'Agua Gourmet', 'color' => '#9b59b6', 'icono' => '🥂'],
    'deportes' => ['nombre' => 'Deportes Acuáticos', 'color' => '#3498db', 'icono' => '🏄'],
    'decoracion' => ['nombre' => 'Decoración', 'color' => '#e74c3c', 'icono' => '⛲'],
    'tecnologia' => ['nombre' => 'Tecnología', 'color' => '#34495e', 'icono' => '💻'],
    'en-accion' => ['nombre' => 'En Acción', 'color' => '#f39c12', 'icono' => '⚡']
];

// Zona horaria Argentina
date_default_timezone_set('America/Argentina/Buenos_Aires');

// ============================================
// INICIALIZACIÓN AUTOMÁTICA
// Crea las carpetas necesarias si no existen
// ============================================
function inicializarSistema() {
    $carpetas = [DATA_PATH, UPLOADS_PATH];
    foreach ($carpetas as $carpeta) {
        if (!is_dir($carpeta)) {
            @mkdir($carpeta, 0755, true);
        }
    }
    
    // Crear archivos JSON vacíos si no existen
    $archivos = [
        DATA_PATH . '/articulos.json' => '[]',
        DATA_PATH . '/videos.json' => '[]',
        DATA_PATH . '/publicidad.json' => '[]'
    ];
    
    foreach ($archivos as $archivo => $contenido) {
        if (!file_exists($archivo)) {
            @file_put_contents($archivo, $contenido);
        }
    }
}

// Ejecutar inicialización
inicializarSistema();

// Función helper para categorías
function getCategoria($slug) {
    global $CATEGORIAS;
    return $CATEGORIAS[$slug] ?? ['nombre' => ucfirst($slug), 'color' => '#2d9cdb', 'icono' => '📰'];
}
